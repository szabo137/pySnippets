
======================================
 Documenting Your Project With Sphinx
======================================

Welcome!

This repository contains all of the course materials
that support the tutorial that Brandon Rhodes presented at PyCon
every year from 2010 through 2013.

The final 2013 version of the tutorial was recorded
and can be watched in its entirety at the pyvideo.org:

http://pyvideo.org/video/1660/documenting-your-project-in-sphinx
